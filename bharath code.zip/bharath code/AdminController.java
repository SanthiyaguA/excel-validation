package com.rise.controller;

/*import java.util.HashMap;
import java.util.Map;
*/
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.rise.dao.UserDAO;
//import com.rise.model.ThresholdValues;
import com.rise.model.User;
//import com.rise.service.AdminService;
import com.rise.service.UserService;

@RestController
@CrossOrigin
@RequestMapping(value="admin")
public class AdminController {

/*	@Autowired
	AdminService adminService;
*/
	@Autowired
	UserService userService;
	
	@Autowired
	UserDAO userDAO;

	
	/*@RequestMapping(value = "readThresholdValues", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Map readThresholdValues() {
		return adminService.readThresholdValues();
	}

	
	@RequestMapping(value = "updateThresholdValues", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public Map updateThresholdValues(@RequestBody ThresholdValues thresholdValues) {
		HashMap<String,String> statusMap = new HashMap();
		if (thresholdValues.getThresholdMap() != null) {
			statusMap.put("status", adminService.updateThresholdValues(thresholdValues.getThresholdMap(), "dynamic"));
		}
		return statusMap;
	}
*/	

	
	@RequestMapping(value = "saveUser", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
	public org.json.simple.JSONObject saveUserDetails(@RequestBody User user) {	
		JSONObject response = new JSONObject();
		if(user != null) {
			boolean flag =  userService.saveUserDetails(user);
			if (flag==true) {
				response.put("status", "User Details Save Success");
			} else {
				response.put("status","User Details Save Fail");
			}
		}
		else {
			response.put("status", "Input Json Empty");
		}
		
		return response;
	}
	
	
	@RequestMapping(value="userlist", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public JSONArray getUserList() throws Exception{
		return userService.listAllUsers();
	}

	
	@RequestMapping(value = "updateUserList", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
	public JSONObject updateUserList(@RequestBody JSONArray user) {	
		JSONObject response = new JSONObject();
		if(user != null) {
			userService.updateUserList(user);
			response.put("status", "Success");
		}
		else {
			response.put("status", "Input Json Empty");
		}
		return response;
	}
	

	@RequestMapping(value = "updateUser", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
	public JSONObject updateOneUser(@RequestBody User user) {	
		JSONObject response = new JSONObject();
		if(user != null) {
			if(userDAO.checkUsers(user.getUser_name()) == 0) {
				response.put("status", "User Not Exists");
			}
			else {
				userService.updateOneUser(user);
				response.put("status", "Success");
			}
		}
		else {
			response.put("status", "Input Json Empty");
		}
		return response;
	}
	
	@RequestMapping(value = "deleteUser/{user_name}", method = RequestMethod.GET)
	public String deleteUser(@PathVariable ("user_name") String user_name) {
		
		if(user_name != null) {
			if(userDAO.checkUsers(user_name) > 0) {
				System.out.println("Inside User present");
				if(userDAO.deleteUser(user_name))
				return "success";
			}
			else {
				return "User Not Exists";
			}
		}
		else {
			return "Please enter User Name";
		}
		
		return "fail";
	}
	
	
	@RequestMapping(value="userExist/{user_name}", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public String getUser(@PathVariable ("user_name") String user_name) throws Exception{
		String flag = "User Name already Exists";
		if(userDAO.checkUsers(user_name)==0) {
			flag = "Not Exists";
		}
		return flag;
	}
	
	
	/*@RequestMapping(value = "updateExternalChart", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
	public String updateExternalServices(@RequestBody org.json.simple.JSONObject ext) {	
		if(ext != null) {
			adminService.updateExternalServices(ext);
			return "Success";
		}
		else {
			return "Input Json Empty";
		}
	}
*/	
	
	@RequestMapping(value="userData/{email_id}", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public JSONObject getUserDetail(@PathVariable ("email_id") String email_id) throws Exception{
		JSONObject flag = new JSONObject();
		if(userDAO.checkUsersEmail(email_id)>0) {
			flag.put("status", "User Exist");
			flag.put("data", userService.getUser(email_id));
		}
		else {
			flag.put("status", "User Not Exists");
		}
		return flag;
	}
	
	@RequestMapping(value="userDetails/{user_name}", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public JSONObject getUserData(@PathVariable ("user_name") String user_name) throws Exception{
		JSONObject flag = new JSONObject();
		if(userDAO.checkUsers(user_name)>0) {
			flag.put("status", "User Exist");
			flag.put("data", userService.getUserDetails(user_name));
		}
		else {
			flag.put("status", "User Not Exists");
		}
		return flag;
	}
	
	/*@RequestMapping(value="purge", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public String deleteDatabase() throws Exception{
		 //adminService.deleteDatabase();
		 return "success";
	}*/
}
