package com.rise.dao;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;

@Component
public class UserDAO {
	
	Logger log = LoggerFactory.getLogger(this.getClass());

	@Autowired MongoDatabase database;
	
	public boolean saveUserDetails(Document document) {
		
		log.info("saving User data Start");
		MongoCollection<Document> userDetail = database.getCollection("user");
		userDetail.insertOne(document);
		log.info("saving User data End");
		return true;
	}
	
	public List<Document> listallUsers(){
		log.info("retrieve user data start");
		MongoCollection<Document> userCollection = database.getCollection("user");
		BasicDBObject queryObject = new BasicDBObject();
		List<Document> documents = (List<Document>) userCollection.find().into(new ArrayList<Document>());
		log.info("retrieve user data end");
		return documents;
	}
	
	public int checkUsers(String userName){
		
		log.info("retrieve user data start");
		MongoCollection<Document> userCollection = database.getCollection("user");
		BasicDBObject queryObject = new BasicDBObject();
		queryObject.put("user_name", userName);
		List<Document> documents = (List<Document>) userCollection.find(queryObject).into(new ArrayList<Document>());
		log.info("retrieve user data end");
		
		return documents.size();
	}
	
	public int checkUsersEmail(String email_id){
		
		log.info("retrieve user data start");
		MongoCollection<Document> userCollection = database.getCollection("user");
		BasicDBObject queryObject = new BasicDBObject();
		queryObject.put("email_id", email_id);
		List<Document> documents = (List<Document>) userCollection.find(queryObject).into(new ArrayList<Document>());
		log.info("retrieve user data end");
		
		return documents.size();
	}
	
	public boolean updateUser(String userName, BasicDBObject updateObj) {
		
		log.info("updating user data start");
		MongoCollection<Document> userCollection = database.getCollection("user");
		
		userCollection.updateOne(Filters.eq("user_name", userName), Updates.set("first_name", updateObj.get("first_name")));
		userCollection.updateOne(Filters.eq("user_name", userName), Updates.set("last_name", updateObj.get("last_name")));
		userCollection.updateOne(Filters.eq("user_name", userName), Updates.set("email_id", updateObj.get("email_id")));
		userCollection.updateOne(Filters.eq("user_name", userName), Updates.set("role", updateObj.get("role")));
		userCollection.updateOne(Filters.eq("user_name", userName), Updates.set("last_session", updateObj.get("last_session")));
		
		log.info("updating user data end");
		return true;
	}
	
	public boolean deleteUser(String userName) {
		log.info("Deleting user data start");
		
		MongoCollection<Document> userCollection = database.getCollection("user");
		userCollection.deleteOne(Filters.eq("user_name", userName));
		
		log.info("Deleting user data end");
		return true;
	}
	
	public Document getUser(String email_id){
		log.info("retrieve user data start");
		MongoCollection<Document> userCollection = database.getCollection("user");
		BasicDBObject queryObject = new BasicDBObject();
		queryObject.put("email_id", email_id);
		Document document = new Document();
		
		Iterable<Document> docs = userCollection.find(queryObject);
		
		for (Document doc : docs) {
			document = doc;
        }
		
		log.info("retrieve user data end");
		
		return document;
	}
	
	public Document getUserDetails(String user_name){
		log.info("retrieve user data start");
		MongoCollection<Document> userCollection = database.getCollection("user");
		BasicDBObject queryObject = new BasicDBObject();
		queryObject.put("user_name", user_name);
		Document document = new Document();
		
		Iterable<Document> docs = userCollection.find(queryObject);
		
		for (Document doc : docs) {
			document = doc;
        }
		
		log.info("retrieve user data end");
		
		return document;
	}
}
