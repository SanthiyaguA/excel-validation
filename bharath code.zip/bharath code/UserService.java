package com.rise.service;

import java.util.List;

import org.bson.Document;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mongodb.BasicDBObject;
import com.rise.dao.UserDAO;
import com.rise.model.User;

@Service
public class UserService {

	@Autowired UserDAO userDAO;

	public boolean saveUserDetails(User user) {

		boolean flag = false;

		Document document = new Document();

		document.append("first_name", user.getFirst_name());
		document.append("last_name", user.getLast_name());
		document.append("user_name", user.getUser_name());
		document.append("email_id", user.getEmail_id());
		document.append("role", user.getRole());
		document.append("last_session", user.getLast_session());

		int count = userDAO.checkUsers(user.getUser_name());

		if(count==0) {
			if(userDAO.saveUserDetails(document)) {
				flag = true;
			}
		}else {
			flag = false;
		}
		return flag;
	}

	public JSONArray listAllUsers() {

		JSONParser parser = new JSONParser();
		List<Document> userListDocs = userDAO.listallUsers();
		JSONArray userList = new JSONArray();

		for (Document doc : userListDocs) {

			JSONArray arrOfData = new JSONArray();
			String json = doc.toJson();
			JSONObject userObj;
			try {
				userObj = (JSONObject) parser.parse(json);
				userList.add(userObj);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return userList;
	}

	public boolean updateUserList(JSONArray userList) {

		for (int i = 0; i < userList.size(); i++) {
			JSONObject userObj = (JSONObject) userList.get(i);
			User user = new User();
			user.setFirst_name(userObj.get("first_name").toString());
			
			
			if(updateOneUser(user)) {
				return true;
			}
		}

		return false;
	}

	public boolean updateOneUser(User userObj) {

		boolean flag = false;

		BasicDBObject queryObject = new BasicDBObject();
		
		queryObject.put("first_name", userObj.getFirst_name());
		queryObject.put("last_name", userObj.getLast_name());
		queryObject.put("email_id",userObj.getEmail_id());
		queryObject.put("role", userObj.getRole());
		queryObject.put("last_session", userObj.getLast_session());

		if(userDAO.updateUser(userObj.getUser_name(), queryObject)) {
			flag = true;
		}

		return flag;
	}
	
	public JSONObject getUser(String email_id) {

		JSONParser parser = new JSONParser();
		Document doc = userDAO.getUser(email_id);

			String json = doc.toJson();
			JSONObject userObj = new JSONObject();
			try {
				userObj = (JSONObject) parser.parse(json);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		return userObj;
	}
	
	public JSONObject getUserDetails(String user_name) {

		JSONParser parser = new JSONParser();
		Document doc = userDAO.getUserDetails(user_name);

			String json = doc.toJson();
			JSONObject userObj = new JSONObject();
			try {
				userObj = (JSONObject) parser.parse(json);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		return userObj;
	}

}
