package com.rise.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class User {
	
	@JsonProperty("first_name")
	private String first_name;
	
	@JsonProperty("last_name")
	private String last_name;
	
	@JsonProperty("user_name")
	private String user_name;
	
	@JsonProperty("email_id")
	private String email_id;
	
	@JsonProperty("role")
	private String role;
	
	@JsonProperty("last_session")
	private String last_session;

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getLast_session() {
		return last_session;
	}

	public void setLast_session(String last_session) {
		this.last_session = last_session;
	}

	@Override
	public String toString() {
		return "User [first_name=" + first_name + ", last_name=" + last_name + ", user_name=" + user_name
				+ ", email_id=" + email_id + ", role=" + role + ", last_session=" + last_session + "]";
	}
	
}
