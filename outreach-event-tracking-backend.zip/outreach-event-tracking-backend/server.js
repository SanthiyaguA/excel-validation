var express = require('express'),
    app = express(),
    port = process.env.PORT || 3000,
    mongoose = require('mongoose'),
    cors = require('cors'),
    bodyParser = require('body-parser'),
    cron = require('node-cron'),
    mailService = require('../hack/api/services/mailService');

// mongoose instance connection url connection
mongoose.Promise = global.Promise;
var connStr = 'mongodb://localhost/outreach';

mongoose.connect(connStr, { useNewUrlParser: true, useCreateIndex: true, }, function (err) {
    if (err) throw err;
    console.log('Successfully connected to MongoDB');
});

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());

//Uncomment for Cron Sheduler
cron.schedule('0 0 * * *', function() {
  console.log("---------------------");
  console.log("Running Cron Job");
  mailService.sendMail();
});

var routes = require('./api/routes/userRoutes'); //importing route
routes(app); //register the route

app.listen(port);


console.log('todo list RESTful API server started on: ' + port);