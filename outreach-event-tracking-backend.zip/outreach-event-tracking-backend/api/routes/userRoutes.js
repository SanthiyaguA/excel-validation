'use strict';
var userService = require('../services/userService');
var activityService = require('../services/activityService');
var eventService = require('../services/eventService');
var mailService = require('../services/mailService');

module.exports = function (app) {

    app.post('/register', (req, res) => {
        userService.getPocData(req.body).then(data => {
            res.send(data);
        })
            .catch(err => {
                res.send(err);
            });
    });

    app.get('/login/:emp_id/:password', (req, res) => {
        userService.getlogin(req.params).then(data => {
            res.send(data);
        })
            .catch(err => {
                res.send(err);
            });
    });

    app.post('/activity', (req, res) => {
        activityService.addActivity(req.body).then(data => {
            res.send(data);
        })
            .catch(err => {
                res.send(err);
            });
    });

    app.get('/activity', (req, res) => {
        activityService.listActivity().then(data => {
            res.send(data);
        })
            .catch(err => {
                res.send(err);
            });
    });

    app.post('/createEvent', (req, res) => {
        eventService.addEvent(req.body).then(data => {
            res.send(data);
        })
            .catch(err => {
                res.send(err);
            });
    });

    app.get('/eventList/:emp_id', (req, res) => {
        eventService.listEvent(req.params).then(data => {
            res.send(data);
        })
            .catch(err => {
                res.send(err);
            });
    });

    app.put('/updateEvent', (req, res) => {
        eventService.updateEvent(req.body).then(data => {
            res.send(data);
        })
            .catch(err => {
                res.send(err);
            });
    });

    app.get('/email', (req, res) => {
        mailService.sendMail().then(data => {
            res.send(data);
        })
            .catch(err => {
                res.send(err);
            });
    });

};