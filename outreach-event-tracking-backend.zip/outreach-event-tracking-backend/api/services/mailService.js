'use strict';
var eventService = require('../services/eventService');
var date = require('date-and-time');
var nodemailer = require('nodemailer');

function getMail() {
    try {
        return new Promise((resolve, reject) => {
            var final = {};
            eventService.futureEvent().then(response => {
                var datas = response.data;
                for (var obj in datas) {
                    var data = datas[obj];
                    var tasks = data.task;
                    for (var tsk in tasks) {
                        let now = new Date();
                        let eve = new Date(tasks[tsk].end_date);
                        var current_date = date.format(now, 'YYYY/MM/DD');
                        var event_date = date.format(eve, 'YYYY/MM/DD');

                        if (tasks[tsk].status != "completed" && current_date <= event_date) {

                            var transporter = nodemailer.createTransport({
                                service: 'gmail',
                                auth: {
                                    xoauth2: xoauth2.createXOAuth2Generator({
                                        user: 'bharath@gmail.com',
                                        clientId: 'XXXXXXXXXXXX-XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX.apps.googleusercontent.com',
                                        clientSecret: 'XXXXXXXXXXXXXXXXXXXXXXXX',
                                        refreshToken: 'X/XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
                                    })
                                }
                            })

                            var mailOptions = {
                                from: 'bharath@gmail.com',
                                to: 'sbharathkumar@gmail.com',
                                subject: 'Sending Email using Node.js',
                                text: 'Hi your ' + tasks[tsk].task_name + ' is pending please do as soon as possible'
                            };

                            transporter.sendMail(mailOptions, function (error, info) {
                                if (error) {
                                    console.log(error);
                                    reject(error);
                                } else {
                                    console.log('Email sent: ' + info.response);
                                    final['status'] = 200;
                                    final['data'] = info.response;
                                    resolve(final);
                                }
                            });

                        }
                    }
                    console.log("------------------------");
                }

            }).catch(err => {
                console.log(err);
            });
        })
    } catch (error) {

    }
}

module.exports = {
    sendMail() {
        return new Promise((resolve, reject) => {
            getMail().then((data) => {
                resolve(data);
            }, (err) => {
                reject(err);
            }).catch(e => console.log(e));
        })
    },
    getMail: getMail
}