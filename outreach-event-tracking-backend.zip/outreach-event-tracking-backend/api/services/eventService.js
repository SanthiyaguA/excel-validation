'use strict';
var Event = require('../models/eventModel');
var datetime = require('node-datetime');
var date = datetime.create();

function getAddEvent(req) {
    try {
        return new Promise((resolve, reject) => {
            var addEvent = new Event(req);
            addEvent.save(function (err, data) {
                var final = {};
                if (err) {
                    reject(err);
                } else {
                    final['status'] = 200;
                    //final['data'] = data;
                    resolve(final);
                }
            });
        })
    } catch (error) {
        console.log(error);
    }
}

function getEventList(req) {
    try {
        return new Promise((resolve, reject) => {
            var format = date.format('Y-m-d H:M:S');
            Event.find({ $and: [{ emp_id: req.emp_id }, { date_of_event: { $gte: format } }] }, function (err, event) {
                var final = {};
                if (err) {
                    reject(err);
                } else {
                    final['status'] = 200;
                    final['data'] = event;
                    resolve(final);
                }
            });
        })
    } catch (error) {
        console.log(error);
    }
}

function getUpdate(req) {
    try {
        return new Promise((resolve, reject) => {
            console.log(req._id);
            Event.findOneAndUpdate({ _id: req._id }, req, { new: true }, function (err, event) {
                var final = {};
                if (err) {
                    reject(err);
                } else {
                    final['status'] = 200;
                    final['data'] = event;
                    resolve(final);
                }
            });
        })
    } catch (error) {
        console.log(error);
    }
}

function getFutureEvent(req) {
    try {
        return new Promise((resolve, reject) => {
            var format = date.format('Y-m-d H:M:S');
            Event.find({ date_of_event: { $gte: format } }, function (err, event) {
                var final = {};
                if (err) {
                    reject(err);
                } else {
                    final['status'] = 200;
                    final['data'] = event;
                    resolve(final);
                }
            });
        })
    } catch (error) {
        console.log(error);
    }
}

module.exports = {

    addEvent(req) {
        return new Promise((resolve, reject) => {
            getAddEvent(req).then((data) => {
                resolve(data);
            }, (err) => {
                reject(err);
            }).catch(e => console.log(e));
        })
    },

    listEvent(req) {
        return new Promise((resolve, reject) => {
            getEventList(req).then((data) => {
                resolve(data);
            }, (err) => {
                reject(err);
            }).catch(e => console.log(e));
        })
    },

    updateEvent(req) {
        return new Promise((resolve, reject) => {
            getUpdate(req).then((data) => {
                resolve(data);
            }, (err) => {
                reject(err);
            }).catch(e => console.log(e));
        })
    },

    futureEvent() {
        return new Promise((resolve, reject) => {
            getFutureEvent().then((data) => {
                resolve(data);
            }, (err) => {
                reject(err);
            }).catch(e => console.log(e));
        })
    },

    getAddEvent: getAddEvent,
    getEventList: getEventList,
    getUpdate: getUpdate,
    getFutureEvent: getFutureEvent

}