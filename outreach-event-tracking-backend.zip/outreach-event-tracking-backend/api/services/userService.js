'use strict';
var User = require('../models/userModel')

function getPocDetails(req) {
    try {
        return new Promise((resolve, reject) => {
            var testUser = new User({
                emp_name: req.emp_name,
                emp_id: req.emp_id,
                email_id: req.email_id,
                password: req.password
            });

            // save user to database
            testUser.save(function (err, data) {
                var final = {};
                if (err) {
                    reject(err);
                } else {
                    final['status'] = 200;
                    final['data'] = data;
                    resolve(final);
                }
            });
        })
    } catch (error) {
        console.log(error);
    }
}

function login(req) {
    try {
        return new Promise((resolve, reject) => {
            User.findOne({ emp_id: req.emp_id }, function (err, user) {
                var final = {};
                if (err) {
                    final['status'] = 400;
                    final['msg'] = "Invalid Employee Id";
                    reject(final);
                }
                // test password
                user.comparePassword(req.password, function (err, isMatch) {
                    if (isMatch === false) {
                        final['msg'] = "Passsword Mismatch";
                        reject(final);
                    } else {
                        final['status'] = 200;
                        final['data'] = user;
                        resolve(final);
                    }
                    // console.log('Password123:', isMatch); // -&gt; Password123: true
                });
            });
        })
    } catch (error) {
        console.log(error);
    }
}

module.exports = {

    getPocData(req) {
        return new Promise((resolve, reject) => {
            getPocDetails(req).then((data) => {
                resolve(data);
            }, (err) => {
                reject(err);
            }).catch(e => console.log(e));
        })
    },

    getlogin(req) {
        return new Promise((resolve, reject) => {
            login(req).then((data) => {
                resolve(data);
            }, (err) => {
                reject(err);
            }).catch(e => console.log(e));
        })
    },

    getPocDetails: getPocDetails,
    login: login

}