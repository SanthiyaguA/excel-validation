'use strict';
var Activity = require('../models/activityModel');

function getAddActivity(req) {
    try {
        return new Promise((resolve, reject) => {
            var addaActivity = new Activity(req);
            addaActivity.save(function (err, data) {
                var final = {};
                if (err) {
                    reject(err);
                } else {
                    final['status'] = 200;
                    final['data'] = data;
                    resolve(final);
                }
            });
        })
    } catch (error) {
        console.log(error);
    }
}

function getListActivity() {
    try {
        return new Promise((resolve, reject) => {
            Activity.find({}, function (err, activity) {
                var final = {};
                if (err) {
                    reject(err);
                } else {
                    final['status'] = 200;
                    final['data'] = activity;
                    resolve(final);
                }
            });
        })
    } catch (error) {
        console.log(error);
    }
}

module.exports = {

    addActivity(req) {
        return new Promise((resolve, reject) => {
            getAddActivity(req).then((data) => {
                resolve(data);
            }, (err) => {
                reject(err);
            }).catch(e => console.log(e));
        })
    },

    listActivity() {
        return new Promise((resolve, reject) => {
            getListActivity().then((data) => {
                resolve(data);
            }, (err) => {
                reject(err);
            }).catch(e => console.log(e));
        })
    },

    getAddActivity: getAddActivity,
    getListActivity: getListActivity

}