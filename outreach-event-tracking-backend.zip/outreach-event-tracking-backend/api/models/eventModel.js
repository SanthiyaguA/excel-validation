'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema;

var EventSchema = new Schema({
    emp_id: { type: String, required: true },
    event_name: { type: String, required: true },
    date_of_event: { type: Date, required: true },
    category_name: { type: String, required: true },
    task: { type: JSON, required: true }
});

const EventModel = mongoose.model('event', EventSchema);
module.exports = EventModel;