'use strict';
var mongoose = require('mongoose');
var Schema = mongoose.Schema;


var ActivitySchema = new Schema({
    activity_name: { type: String, required: true },
    days: { type: Number,  required: true },
    category_id: {type: Schema.Types.ObjectId, ref: 'CategoryModel'}
});

const ActivityModel = mongoose.model('activity', ActivitySchema);
module.exports = ActivityModel;