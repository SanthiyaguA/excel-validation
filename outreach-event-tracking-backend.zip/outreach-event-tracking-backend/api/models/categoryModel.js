'use strict';
var mongoose = require('mongoose');
var Schema = mongoose.Schema;


var CategorySchema = new Schema({
    category_name: { type: String, required: true },
    comment: { type: String }
});

const CategoryModel = mongoose.model('category', CategorySchema);
module.exports = CategoryModel;